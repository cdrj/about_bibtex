create view test_group as
select `f`.`name` AS `name`, `p`.`pub_name` AS `pub_name`, `levenshtein_ratio`(`f`.`name`, `p`.`pub_name`) AS `ratio`
from `test`.`fellows` `f`
         join `test`.`publications` `p`;

